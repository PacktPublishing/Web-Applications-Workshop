"use strict";


const menuItems = [
    {
        name: "Fish and Chips",
        description:
            "Battered cod served with chips, mushy peas and tartare sauce.",
        price: 13.95
    },
    {
        name: "Steak and Ale Pie",
        description:
            "Slow-cooked beef in a rich ale gravy with buttery pastry.",
        price: 15.25
    },
    {
        name: "Vegetable Pie",
        description:
            "Seasonal vegetables in a creamy herb sauce with flaky pastry.",
        price: 11.50
    },
    {
        name: "Apple Crumble",
        description:
            "Warm baked apples with a golden crumble topping and custard.",
        price: 6.25
    }
];


const orderItems = [];


const menuContainer =
    document.getElementById("menuItems");

const orderContainer =
    document.getElementById("orderItems");

const subtotalOutput =
    document.getElementById("subtotal");

const deliveryOutput =
    document.getElementById("delivery");

const totalOutput =
    document.getElementById("total");

const orderTypeInput =
    document.getElementById("orderType");

const checkoutForm =
    document.getElementById("checkoutForm");

const confirmationSection =
    document.getElementById("confirmation");

const confirmationMessage =
    document.getElementById("confirmationMessage");


function formatCurrency(value) {

    return "£" + value.toFixed(2);

}


function displayMenu() {

    let menuHTML = "";


    for (let i = 0; i < menuItems.length; i++) {

        const item =
            menuItems[i];


        menuHTML +=
            '<article class="menu-item">' +

                "<h3>" +
                    item.name +
                "</h3>" +

                "<p>" +
                    item.description +
                "</p>" +

                '<p class="menu-price">' +
                    formatCurrency(item.price) +
                "</p>" +

                '<button type="button" ' +
                    'class="add-button" ' +
                    'data-index="' + i + '">' +
                    "Add to Order" +
                "</button>" +

            "</article>";

    }


    menuContainer.innerHTML =
        menuHTML;


    const addButtons =
        document.querySelectorAll(".add-button");


    for (const button of addButtons) {

        button.addEventListener(
            "click",
            function () {

                const index =
                    Number(
                        button.dataset.index
                    );


                orderItems.push(
                    menuItems[index]
                );


                displayOrder();

            }
        );

    }

}


function calculateSubtotal() {

    let subtotal = 0;


    for (const item of orderItems) {

        subtotal +=
            item.price;

    }


    return subtotal;

}


function calculateDelivery() {

    const subtotal =
        calculateSubtotal();


    if (orderTypeInput.value === "collection") {

        return 0;

    }


    if (subtotal === 0 || subtotal >= 25) {

        return 0;

    }


    return 2.50;

}


function calculateTotal() {

    return (
        calculateSubtotal() +
        calculateDelivery()
    );

}


function displayOrder() {

    let orderHTML = "";


    if (orderItems.length === 0) {

        orderHTML =
            "<p>Your order is currently empty.</p>";

    } else {

        for (const item of orderItems) {

            orderHTML +=
                "<p>" +
                    item.name +
                    " — " +
                    formatCurrency(item.price) +
                "</p>";

        }

    }


    orderContainer.innerHTML =
        orderHTML;


    subtotalOutput.textContent =
        formatCurrency(
            calculateSubtotal()
        );


    deliveryOutput.textContent =
        formatCurrency(
            calculateDelivery()
        );


    totalOutput.textContent =
        formatCurrency(
            calculateTotal()
        );

}


function updateOrderType() {

    displayOrder();

}


function placeOrder(event) {

    event.preventDefault();


    if (orderItems.length === 0) {

        alert(
            "Add at least one item before placing your order."
        );

        return;

    }


    const customerName =
        document
            .getElementById("customerName")
            .value
            .trim();


    const orderType =
        orderTypeInput.value;


    const orderTotal =
        calculateTotal();


    confirmationMessage.textContent =
        "Thank you, " +
        customerName +
        ". Your " +
        orderType +
        " order total is " +
        formatCurrency(orderTotal) +
        ".";


    confirmationSection.hidden =
        false;


    orderItems.length = 0;


    checkoutForm.reset();


    displayOrder();

}


orderTypeInput.addEventListener(
    "change",
    updateOrderType
);


checkoutForm.addEventListener(
    "submit",
    placeOrder
);


displayMenu();

displayOrder();