"use strict";

const menuItems = [
    {
        name: "Fish and Chips",
        description: "Battered cod served with chips, mushy peas and tartare sauce.",
        price: 13.95
    },
    {
        name: "Steak and Ale Pie",
        description: "Slow-cooked beef in a rich ale gravy with buttery pastry.",
        price: 15.25
    },
    {
        name: "Vegetable Pie",
        description: "Seasonal vegetables in a creamy herb sauce with flaky pastry.",
        price: 11.50
    },
    {
        name: "Apple Crumble",
        description: "Warm baked apples with a golden crumble topping and custard.",
        price: 6.25
    }
];

const orderItems = [];

const menuContainer = document.getElementById("menuItems");

const orderContainer = document.getElementById("orderItems");

const subtotalOutput = document.getElementById("subtotal");

const deliveryOutput = document.getElementById("delivery");

const totalOutput = document.getElementById("total");

const orderTypeInput = document.getElementById("orderType");

const checkoutForm = document.getElementById("checkoutForm");

const confirmationSection = document.getElementById("confirmation");

const confirmationMessage = document.getElementById("confirmationMessage");


function formatCurrency(value) {

    // Complete this function.

}


function displayMenu() {

    let menuHTML = "";

    for (let i = 0; i < menuItems.length; i++) {

        const item =  menuItems[i];

        menuHTML +=
            '<article class="menu-item">' +

                "<h3>" +
                    item.name +
                "</h3>" +

                "<p>" +
                    item.description +
                "</p>" +

                '<p class="menu-price">' +
                    formatCurrency(item.price) +
                "</p>" +

                '<button type="button" ' +
                    'class="add-button" ' +
                    'data-index="' + i + '">' +
                    "Add to Order" +
                "</button>" +

            "</article>";
    }


    menuContainer.innerHTML = menuHTML;

    const addButtons = document.querySelectorAll(".add-button");

    for (const button of addButtons) {
        button.addEventListener( "click", function () {
                const index =
                    Number(
                        button.dataset.index
                    );

                // Add the selected menu item
                // to the order here.
                // use orderItems list

                displayOrder();
            }
        );
    }
}


function calculateSubtotal() {

    // Complete this function.

}


function calculateDelivery() {

    // Complete this function.

}


function calculateTotal() {

    // Complete this function.

}


function displayOrder() {

    // Complete this function.

}


function updateOrderType() {

    // Complete this function.

}


function placeOrder(event) {

    // Prevent the normal form submission.


    // Check that the order contains
    // at least one item.


    // Read the customer's name.


    // Get the selected order type.


    // Calculate the final order total.


    // Display the confirmation message.


    // Show the confirmation section.


    // Clear the order.


    // Reset the form.


    // Update the order display.

}


// Add a change event listener
// to the order type control.


// Add a submit event listener
// to the checkout form.


// Display the menu.


// Display the initial order summary.